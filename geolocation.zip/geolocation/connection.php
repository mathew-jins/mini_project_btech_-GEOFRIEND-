<?php
$con=mysqli_connect("localhost","root","","learn");
?>