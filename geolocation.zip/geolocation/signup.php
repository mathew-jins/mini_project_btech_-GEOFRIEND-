<?php
	include("header.php");
?>


<section class="section appoinment">
	<div class="container">
		<div class="row align-items-center">
			
			<div class="col-lg-12 col-md-10 ">
				<div class="appoinment-wrap mt-5 mt-lg-0">
					<h2 class="mb-2 title-color">Create New Account</h2>
					     <form id="#" method="post" action="#">
                    <div class="row">
                         <div class="col-lg-6">
                            <div class="form-group">
                                <input name="name" id="name" type="text" class="form-control" placeholder="Name" required>
                            </div>
                        </div>
						<div class="col-lg-6">
                            <div class="form-group">
                                <input name="age" id="time" type="number" class="form-control" placeholder="Age" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <input name="phno" id="phno" type="text" class="form-control" placeholder="Contact Number" required>
                            </div>
                        </div>
						<div class="col-lg-6">
                            <div class="form-group">
                                <select class="form-control" name="gender" id="exampleFormControlSelect2" required>
                                  <option>Gender</option>
                                  <option value="male">Male</option>
                                  <option value="female">Female</option>
								  <option value="others">Others</option>
                                </select>
                            </div>
                        </div>
						
                        <div class="col-lg-6">
                            <div class="form-group">
                                <input name="mail" id="name" type="text" class="form-control" placeholder="Mail ID" required>
                            </div>
                        </div>
                   
					<div class="col-lg-6">
                            <div class="form-group">
                                <input name="username" id="username" type="text" class="form-control" placeholder="Create a username" required>

                            </div>
                    </div>
					<div class="col-lg-6">
                            <div class="form-group">
                                <input name="password" id="passwordd" type="password" class="form-control" placeholder="Create a password" required>

                            </div>
                    </div>
					</div>
                    <input  type="submit" class="btn btn-main btn-round-full" name="submit" value="Create Account" >
                </form>
				
				
				<?php
						$con=mysqli_connect("localhost","root","","learn");
						error_reporting(0);
						if(isset($_POST['submit']))
 
						{

							$name=$_POST['name'];
							$phno=$_POST['phno'];
							$mail=$_POST['mail'];
							$age=$_POST['age'];
							$gender=$_POST['gender'];
							$username=$_POST['username'];
							$password=$_POST['password'];
	
 
							$ins="INSERT INTO signup(name,age,phno,gender,mail,username,password)
							VALUES('$name','$age','$phno','$gender','$mail','$username','$password')";
							$res= mysqli_query($con,$ins);
							if($res)
							{
								echo "<script>
								alert('insert successfully')
								</script>";
						}
					}	

				?>
            </div>
			</div>
		</div>
	</div>
</section>
<?php
	include("footer.php");
?>