import folium
import mysql.connector
import pandas as pd
import joblib

mydb = mysql.connector.connect(
	host="localhost",
	user="root",
	password="",
	database="learn"
	)

file=open("catlist.txt","r")
cat_list=file.read()
file.close()
cat_list=list(cat_list.split(","))
print(cat_list)

#cat_id=[1,4,3,9,1,13,15,11,8]

cat_id=[]
for i in cat_list:
    print(i)
    try:
        cat_id.append(int(i))
    except:
        pass

#user_id=cat_id[1]
college=cat_id[0]
food=cat_id[1]
"""shop=cat_id[2]
gym=cat_id[3]
hospital=cat_id[4]
hostels=cat_id[5]
theatre=cat_id[6]
parks=cat_id[7]"""



#Locating base location.. 
cursor = mydb.cursor()
#sql="SELECT * FROM college WHERE id=%s"
#val=(college)
cursor.execute("SELECT * FROM college WHERE id={}".format(college))

result = cursor.fetchall()
print(result)

college_lat=result[0][2]
college_log=result[0][3]

#print(college_lat,college_log)




my_map = folium.Map(location = [college_lat, college_log],
										zoom_start = 20)


folium.Marker([college_lat, college_log],
               popup = 'College',icon=folium.Icon(color='green',icon_color='#FFFF00')).add_to(my_map)



cursor = mydb.cursor()
#sql="SELECT * FROM college WHERE id=%s"
#val=(college)
query="SELECT * FROM cat_info"

cursor.execute(query)

result = cursor.fetchall()
	
	
file=open("Budget.txt","r")
budget=eval(file.read())
file.close()

file=open("rating.txt","r")
rating=eval(file.read())
file.close()

file=open("model.joblib","rb")
model=joblib.load(file)
file.close()

file=open("label.joblib","rb")
le=joblib.load(file)
file.close()

color_code={'Eco':'#00FF00','Bus':'#0000FF','Prem':'#8F00FF'}

for i in result:
	#print(i[4],i[5])
	data=pd.DataFrame({'rating':[i[4].strip()],'Budget':[i[5].strip()]})
	data['Budget'].replace(budget,inplace=True)
	data['rating'].replace(rating,inplace=True)
	#print(data)
	pred=model.predict(data)
	out=le.inverse_transform(pred)[0]
	folium.Marker([i[6], i[7]],
		popup = str(i[1]),icon=folium.Icon(color='blue',icon_color=str(color_code[out.strip()]))).add_to(my_map)
	print(out)
	
	
"""	print(color_code[i[8]])
	folium.Marker([i[6], i[7]],
		popup = str(i[1]),icon=folium.Icon(color='blue',icon_color=str(color_code[i[8]]))).add_to(my_map)"""
	

#print(result)
my_map.save("cat_map_pred.html")
										
										
										
