<?php
	include("header.php");
?>

<section class="section appoinment">
	<div class="container">
		<div class="row align-items-center">
			
			<div class="col-lg-12 col-md-10 ">
			<h2 class="mb-2 title-color">Details</h2>
				<div class="appoinment-wrap mt-5 mt-lg-0">
					<table class="table">
						<tr>
							<th>#</th>
							<th>Name</th>
							<th>Address</th>
							<th>Phone</th>
						</tr>
						
						<?php
							$con=mysqli_connect("localhost","root","","learn");
							error_reporting(0);

							$res= mysqli_query($con,"SELECT * FROM `details`");
							$i=0;
							while($row=mysqli_fetch_array($res))
							{

						?>
						<tr>
							<td><?php echo $i; ?></td>
							<td><?php echo $row['name'] ?></td>
							<td><?php echo $row['address'] ?></td>
							<td><?php echo $row['number'] ?></td>
						</tr>
						
						<?php
						$i++;
							}
						?>

					</table>
            	</div>
			</div>
		</div>
	</div>
</section>






<?php
	include("footer.php");
?>