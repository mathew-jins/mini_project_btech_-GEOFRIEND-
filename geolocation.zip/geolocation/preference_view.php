<?php
	include("header.php");
?>
<section class="section appoinment">
	<div class="container">
		<div class="row align-items-center">
			
			<div class="col-lg-12 col-md-10 ">
				<div class="appoinment-wrap mt-5 mt-lg-0">
					<h2 class="mb-2 title-color">Reviews</h2>
					     <table class="table">
                            <tr>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Contact</th>
                            </tr>
                            <?php
                                $con=mysqli_connect("localhost","root","","learn");
                                $sel="SELECT * FROM `preference` WHERE `user_id`='$_SESSION[id]'";
                                echo $sel;
                                $res=mysqli_query($con,$sel);
                                $row=mysqli_fetch_array($res);
                                $i=1;
                                while($row>1)
                            {
                                $sql="SELECT * FROM `cat_info` where cid='$row[food]'" ;
                                echo $sql;
                                $result=mysqli_query($con,$sql);
                                $row1=mysqli_fetch_array($result);

                            ?>
                                <tr>
                                <td><?php echo $row1['name']; ?></td>
                                <td><?php echo $row1['address']; ?></td>
                                <td><?php echo $row1['contact']; ?></td>
                                </tr>
                            <?php
                            }
                            ?>


                           
                         </table>
                
            </div>
			</div>
		</div>
	</div>
</section>
<?php
	include("footer.php");
?>