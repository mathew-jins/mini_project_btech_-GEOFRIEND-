
# coding: utf-8

# In[7]:


import pandas as pd
import joblib


# In[2]:


data=pd.read_csv("test.csv")
data=data.iloc[:,1:-1]
data


# In[3]:


file=open("Budget.txt","r")
budget=eval(file.read())
file.close()


# In[4]:


file=open("rating.txt","r")
rating=eval(file.read())
file.close()


# In[5]:


data['Budget'].replace(budget,inplace=True)
data['rating'].replace(rating,inplace=True)


# In[6]:


data


# In[8]:


file=open("model.joblib","rb")
model=joblib.load(file)
file.close()


# In[10]:


file=open("label.joblib","rb")
le=joblib.load(file)
file.close()


# In[11]:


pred=model.predict(data)
pred


# In[14]:


out=le.inverse_transform(pred)[0]
print(out)

