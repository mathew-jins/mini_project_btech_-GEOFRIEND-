# import folium package
import folium

my_map = folium.Map(location = [10.0014, 76.3101],
										zoom_start = 20)

"""# CircleMarker with radius
folium.CircleMarker(location = [28.5011226, 77.4099794],
					radius = 50, popup = ' FRI ').add_to(my_map2)"""
					
# Pass a string in popup parameter
"""folium.Marker([28.5011226, 77.4099794],
               popup = ' Geeksforgeeks.org ').add_to(my_map)"""
			   
			   
folium.Marker([10.0014, 76.3101],
               popup = 's3',color='#3186cc').add_to(my_map)
			   
folium.Marker([9.9921, 76.3019],
               popup = 's2',icon=folium.Icon(color='black',icon_color='#FFFF00')).add_to(my_map)
			   
folium.Marker([9.9542, 76.3024],
               popup = 's2',icon=folium.Icon(color='red',icon_color='#FFFF00')).add_to(my_map)
			   
"""			   
folium.Marker([9.9542, 76.3024],
               popup = 's1').add_to(my_map)"""
		


# save as html
my_map.save(" my_map2.html ")
