<?php
	include("header.php");
?>
<section class="section appoinment">
	<div class="container">
		<div class="row align-items-center">
			
			<div class="col-lg-12 col-md-10 ">
				<div class="appoinment-wrap mt-5 mt-lg-0">
					<h2 class="mb-2 title-color">Users</h2>
					     <table class="table">
                            <tr>
                                <th>Name</th>
                                <th>Age</th>
                                <th>Contact</th>
                                <th>Gender</th>
                                <th>Mail</th>
                                <th>username</th>
                                <th>password</th>
                            </tr>
                            <?php
                                $con=mysqli_connect("localhost","root","","learn");
                                $sel="SELECT * FROM `signup`";
                                //echo $sel;
                                $res=mysqli_query($con,$sel);
                                $i=1;
                                while($row=mysqli_fetch_array($res))
                            {
                                //`id`, `name`, `age`, `phno`, `gender`, `mail`, `username`, `password`
                            ?>
                                <tr>
                                <td><?php echo $row['name']; ?></td>
                                <td><?php echo $row['age']; ?></td>
                                <td><?php echo $row['phno']; ?></td>
                                <td><?php echo $row['gender']; ?></td>
                                <td><?php echo $row['mail']; ?></td>
                                <td><?php echo $row['username']; ?></td>
                                <td><?php echo $row['password']; ?></td>
                                </tr>
                            <?php
                            }
                            ?>


                           
                         </table>
                
            </div>
			</div>
		</div>
	</div>
</section>
<?php
	include("footer.php");
?>