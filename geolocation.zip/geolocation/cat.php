<?php
	include("header.php");
?>
<section class="section appoinment">
	<div class="container">
		<div class="row align-items-center">
			
			<div class="col-lg-12 col-md-10 ">
				<div class="appoinment-wrap mt-5 mt-lg-0">
					<h2 class="mb-2 title-color">Add Category</h2>
					     <form id="#" method="post">
                    <div class="row">
                         <div class="col-lg-6">
                            <div class="form-group">
                                <input name="name" id="" type="text" class="form-control" placeholder="Category Name">
                            </div>
							</div>
							<div class= "col-lg-6">
							<div class="form-group">
                                <select class="form-control" name="type" id="">
                                  <option>type</option>
                                  <option value="shop">Shop</option>
                                  <option value="food">food</option>
                                </select>
							</div>
							</div>
                    </div>
					</div>
                    <input type="submit" class="btn btn-main btn-round-full" name="submit" value="Insert" >
                </form>
				
				
				<?php
						$con=mysqli_connect("localhost","root","","learn");
						error_reporting(0);
						if(isset($_POST['submit']))
 
						{

							$cat_name=$_POST['name'];
							$cat_type=$_POST['type'];
 
							$ins="INSERT INTO `cat`( `cat_name`, `type`)
							VALUES('$cat_name','$cat_type')";
							$res= mysqli_query($con,$ins);
							if($res)
							{
								echo "<script>
								alert('insert successfully');
	   
		
							</script>";
							
						}
						}						

			?>
            </div>
			</div>
		</div>
	</div>
</section>
<?php
	include("footer.php");
?>