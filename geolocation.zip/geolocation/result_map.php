<?php
	include("header.php");
?>
<h2 class="mb-2 title-color" style="text-align: right;">machine Learning</h2>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<iframe src="cat_map.html" width=600 height=500 title="category map"></iframe>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<iframe src="cat_map_pred.html" width=600 height=500 title="category map"></iframe>

<a href="view_details.php" class="btn btn-main btn-round-full" style="margin-left: 30px; margin-bottom: 30px;">view details</a>
<br>
<?php
	include("footer.php");
?>