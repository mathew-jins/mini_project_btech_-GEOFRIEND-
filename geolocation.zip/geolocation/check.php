<?php
session_start();
error_reporting(0);
//
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "learn";

$con= new mysqli($servername, $username, $password, $dbname);


$u=$_POST['username'];
$p=$_POST['password'];

if($u=="admin" && $p=="admin")
   {

   $_SESSION['user'] ="admin";
   $_SESSION['username'] ="";
   header("location:admindash.php");


   }
elseif(isset($_POST['submit']))
{
   $sel="SELECT * FROM signup WHERE username='$u' and password='$p'";
$result = mysqli_query($con,$sel) or die(mysql_error());
 $rows = mysqli_num_rows($result);
 echo $rows;
  $row1=mysqli_fetch_array($result);
 
 
 
    echo"". $row1['id'];
        if($rows==1){
     $_SESSION['username'] = $_POST['username'];
$_SESSION['id']=$row1['id'];
$_SESSION['user']="user";

   header ('location:select.php');
   }
   else{
      header("location:login.php?st=fail");

 
   }
 
}

				?>
           
