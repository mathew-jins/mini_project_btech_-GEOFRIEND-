<?php
	include("header.php");
?>
<section class="section appoinment">
	<div class="container">
		<div class="row align-items-center">
			
			<div class="col-lg-12 col-md-10 ">
				<div class="appoinment-wrap mt-5 mt-lg-0">
					<h2 class="mb-2 title-color">Add Data</h2>
					     <form id="#" method="post">
                    <div class="row">
                         <div class="col-lg-6">
                            <div class="form-group">
                                <input name="name" id="name" type="text" class="form-control" placeholder="Name">
                            </div>
                        </div>
						<div class="col-lg-6">
                            <div class="form-group">
                                <input name="address" id="time" type="text" class="form-control" placeholder="Address">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <input name="contact" id="phno" type="text" class="form-control" placeholder="Contact Number">
                            </div>
                        </div>
						
                        <div class="col-lg-6">
                            <div class="form-group">
                                <input name="lat" id="name" type="text" class="form-control" placeholder="Latitude">
                            </div>
                        </div>
						<div class="col-lg-6">
                            <div class="form-group">
                                <input name="lon" id="name" type="text" class="form-control" placeholder="Longitude">
                            </div>
                        </div>
						 <div class="col-lg-6">
                          <div class="form-group">
                                <select class="form-control" name="budget" id="exampleFormControlSelect2">
                                  <option>Budget</option>
                                  <option value="high">High</option>
                                  <option value="mid">Medium</option>
								  <option value="low">Low</option>
                                </select>
                            </div>
							</div>
						 <div class="col-lg-6">
                          <div class="form-group">
                                <select class="form-control" name="rating" id="exampleFormControlSelect2">
                                  <option>Rating</option>
                                  <option value="low">low</option>
                                  <option value="med">medium</option>
								  <option value="high">high</option>
                                </select>
                            </div>
						
                        </div>
						
						
						 <div class="col-lg-6">
                            <div class="form-group">
							
							
								 <select class="form-control" name="cid" id="exampleFormControlSelect2">
								 <option>Select Category</option>
								 <?php
						$con=mysqli_connect("localhost","root","","learn");

						$sel="select * from cat";
						$res=mysqli_query($con,$sel);
						while($row=mysqli_fetch_array($res))
						{

						
						
						?>
                                  <option value="<?php echo $row['id'] ; ?>"><?php echo $row['cat_name']; ?></option>
                                  	<?php
									}
								
								?>
                                </select>
							
                            </div>
                        </div>
                    </div>
					</div>
                    <input type="submit" class="btn btn-main btn-round-full" name="submit" value="Insert" >
                </form>
				
				
				<?php
						$con=mysqli_connect("localhost","root","","learn");
						error_reporting(0);
						if(isset($_POST['submit']))
 
						{

							$name=$_POST['name'];
							$address=$_POST['address'];
							$contact=$_POST['contact'];
							$budget=$_POST['budget'];
							$rating=$_POST['rating'];
							$lat=$_POST['lat'];
							$lon=$_POST['lon'];
							$cid=$_POST['cid'];
 
							$ins="INSERT INTO cat_info(name,address,contact,budget,rating,lat,lon,cid)
							VALUES('$name','$address','$contact','$budget','$rating','$lat','$lon','$cid')";
							$res= mysqli_query($con,$ins);
							if($res)
							{
								echo "<script>
								alert('insert successfully');
	   
		
							</script>";
							
						}	


						}
			?>
            </div>
			</div>
		</div>
	</div>
</section>
<?php
	include("footer.php");
?>