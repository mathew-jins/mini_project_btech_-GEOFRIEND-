<?php
	include("header.php");
?>
<section class="section appoinment">
	<div class="container">
		<div class="row align-items-center">
			
			<div class="col-lg-12 col-md-10 ">
				<div class="appoinment-wrap mt-5 mt-lg-0">
					<h2 class="mb-2 title-color">Reviews</h2>
					     <table class="table">
                            <tr>
                                <th>Username</th>
                                <th>Feedback</th>
                            </tr>
                            <?php
                                $con=mysqli_connect("localhost","root","","learn");
                                $sel="SELECT * FROM `review`";
                                //echo $sel;
                                $res=mysqli_query($con,$sel);
                                $i=1;
                                while($row=mysqli_fetch_array($res))
                            {
                                $sel1="SELECT * FROM `signup` WHERE id='$row[user_id]'";
                                $res1=mysqli_query($con,$sel1);
                                $row1=mysqli_fetch_array($res1)
                            ?>
                                <tr>
                                <td><?php echo $row1['name']; ?></td>
                                <td><?php echo $row['review']; ?></td>
                                </tr>
                            <?php
                            }
                            ?>


                           
                         </table>
                
            </div>
			</div>
		</div>
	</div>
</section>
<?php
	include("footer.php");
?>