import folium
import mysql.connector

mydb = mysql.connector.connect(
	host="localhost",
	user="root",
	password="",
	database="learn"
	)

#mycursor = mydb.cursor()

"""
sql = "UPDATE status SET status = %s WHERE id = %s"
val = (status, id)

mycursor.execute(sql, val)

mydb.commit()"""


file=open("catlist.txt","r")
cat_list=file.read()
file.close()
cat_list=list(cat_list.split(","))
print(cat_list)


cat_id=[]
for i in cat_list:
    print(i)
    try:
        cat_id.append(int(i))
    except:
        pass
    


#cat_id=[1,4,3,9,1,13,15,11,8]

#user_id=cat_id[1]
college=cat_id[0]
food=cat_id[1]
"""shop=cat_id[2]
gym=cat_id[3]
hospital=cat_id[4]
hostels=cat_id[5]
theatre=cat_id[6]
parks=cat_id[7]"""



#Locating base location.. 
cursor = mydb.cursor()
#sql="SELECT * FROM college WHERE id=%s"
#val=(college)
cursor.execute("SELECT * FROM college WHERE id={}".format(college))

result = cursor.fetchall()

college_lat=result[0][2]
college_log=result[0][3]

#print(college_lat,college_log)




my_map = folium.Map(location = [college_lat, college_log],
										zoom_start = 20)


folium.Marker([college_lat, college_log],
               popup = 'College',icon=folium.Icon(color='green',icon_color='#FFFF00')).add_to(my_map)



cursor = mydb.cursor()
#sql="SELECT * FROM college WHERE id=%s"
#val=(college)
query="SELECT * FROM cat_info WHERE cid={}".format(cat_id[1])
for i in cat_id[2:]:
    query+=" OR cid={}".format(i)
print(query)
cursor.execute(query)

result = cursor.fetchall()

color_code={1:'#FF0000',2:'#00FF00',3:'#8F00FF',3:'#FF0000',4:'#FF0000',3:'#FF0000',4:'#FF0000',
	5:'#FF0000',6:'#FF0000',7:'#FF0000',8:'#FF0000',9:'#00FF00',10:'#FF0000',11:'#FF0000',
	12:'#FF0000',13:'#FF0000',14:'#FF0000',15:'#FF0000'}

for i in result:
	print(i[6],i[7])
	print(color_code[i[8]])
	folium.Marker([i[6], i[7]],
		popup = str(i[1]),icon=folium.Icon(color='blue',icon_color=str(color_code[i[8]]))).add_to(my_map)
	
cursor.execute("TRUNCATE TABLE details")
mydb.commit()
print(result)
for i in result:
    print(i[1],i[2],i[3])
    query="INSERT INTO details (name, address,number) VALUES (%s, %s,%s)"
    val=(str(i[1]),str(i[2]),str(i[3]))
    cursor.execute(query,val)
    mydb.commit()
#query="UPDATE details SET name='{}',address='{}',number='{}' WHERE id=1".format('pqr','pqr','pqr')
#print(query)


my_map.save("cat_map.html")
										
										
										
