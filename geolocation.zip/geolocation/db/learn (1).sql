-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 15, 2022 at 01:18 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `learn`
--

-- --------------------------------------------------------

--
-- Table structure for table `cat`
--

CREATE TABLE IF NOT EXISTS `cat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(50) NOT NULL,
  `type` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `cat`
--

INSERT INTO `cat` (`id`, `cat_name`, `type`) VALUES
(1, 'Gym', ''),
(2, 'American', 'food'),
(3, 'Indian', 'food'),
(4, 'Arabic', 'food'),
(5, 'Seafood', 'food'),
(6, 'Italian', 'food'),
(7, 'Chinese', 'food'),
(8, 'Park', ''),
(9, 'Arcade', 'shop'),
(10, 'Street Shops', 'shop'),
(11, 'Theatre', ''),
(12, 'Vegetarian', 'food'),
(13, 'Hospital', ''),
(15, 'Hostel', '');

-- --------------------------------------------------------

--
-- Table structure for table `cat_info`
--

CREATE TABLE IF NOT EXISTS `cat_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `contact` int(200) NOT NULL,
  `budget` varchar(11) NOT NULL,
  `rating` varchar(11) NOT NULL,
  `lat` varchar(200) NOT NULL,
  `lon` varchar(200) NOT NULL,
  `cid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `cat_info`
--

INSERT INTO `cat_info` (`id`, `name`, `address`, `contact`, `budget`, `rating`, `lat`, `lon`, `cid`) VALUES
(1, 'KFC', 'Ground Floor, Radhani Developers Aluva, Akkat Asarikadan Road, Pulinchoode, Kochi, Kerala 682016', 2147483647, 'med', 'high', '10.097493', '76.3466481', 2),
(2, 'AL- Taza', 'Ground floor, Radhani Developers, service road, Pulinchodu Junction, Aluva, Kerala 683101', 2147483647, 'med', 'high', '10.1001443', '76.3321791', 4),
(3, 'Ifthar Restaurant', 'Bank Junction, Karshakashree, Aluva, Kochi, Kerala 683101', 2147483647, 'med', 'med', '10.1002089', '76.3245343', 4),
(4, 'AL ARABIA Arabic Food Court', 'Bank Junction, Karshakashree, Aluva, Kochi, Kerala 683101', 2147483647, 'med', 'med', '10.085733', '76.3130707', 4),
(5, 'ALSAJ Restaurant', '495C+HQM, Aluva - Munnar Rd, Thottumugham, Aluva, Kerala 683105', 2147483647, 'high', 'med', '10.1037795', '76.3294517', 5),
(6, 'Hotel Goodway', 'Periyar Nagar, Aluva, Kerala 683101', 0, 'low', 'low', '10.1045823', '76.3407385', 3),
(7, 'Sulthan Veedu Restaurant', '17/136, Madesseri Building, Thaikkattukara, Aluva, Kerala 683106', 2147483647, 'high', 'high', '10.0864612', '76.3333093', 3),
(8, 'Hotel New Aryas', 'Railway Station Rd, Pump Junction, Aluva, Kochi, Kerala 683101', 2147483647, 'med', 'low', '10.100944', '76.3483753', 12),
(9, 'MeenAviyal Hotel', 'Sub Jail Rd, opposite Zeenath Theatre, Periyar Nagar, Aluva, Kerala', 0, 'med', 'med', '10.100944', '76.3483753', 5),
(12, 'Metro Fashion Mall', 'Catholic centre complex, Railway Station Rd, Aluva, Kerala 683101', 2147483647, 'low', 'low', '10.1072987', '76.3576941', 9),
(13, 'Aluva Market', 'Periyar Nagar, Aluva, Kerala 683101', 0, 'low', 'med', '10.1067717', '76.3488064', 10),
(14, 'Reborn Fitness studio', 'Chakkapan Tower Toll Gate, Pukattupady, Road, Edappally, Kerala 682024', 2147483647, 'high', 'high', '10.0246914', '76.3030028', 1),
(15, 'Fit and Met Fitness Centre', 'Fit and Met Fitness Centre', 2147483647, 'med', 'high', '10.0246914', '76.3030028', 1),
(16, 'LuLu International Shopping Malls Private Limited Kochi', '34/1000, Old NH 47, Edappally Junction, Nethaji Nagar, Edappally, Kochi, Kerala 682024', 2147483647, 'med', 'high', '10.02469', '76.3030028', 9),
(17, 'Oberon Mall', 'Oberon Mall', 0, 'high', 'med', '10.02469', '76.3030028', 9),
(18, 'Fashion Street', 'X7HQ+75Q, Shenoys, Ernakulam, Kerala 682035', 2147483647, 'low', 'med', '9.9860301', '76.2101976', 10),
(19, 'Market Road , Ekm', 'Market Rd, Convent Junction, Shenoys, Kochi, Kerala 682011', 0, 'low', 'med', '9.9776667', '76.2791706', 10),
(20, 'PVR Cinemas', '34/1000, Old NH 47, Edappally Junction, Nethaji Nagar, Edappally, Kochi, Kerala 682025', 34, 'high', 'high', '10.0279129', '76.2993764', 11),
(21, 'M.A.J. Hospital', 'Market Rd, Edappally, Kochi, Kerala 682024', 2147483647, 'med', 'high', '10.1000953', '76.2172817', 13),
(22, 'Royal Stay - Gents Hostel in Edappally', '32/429,EGRA - 3A Edappally - Pukkaattupady Road, Near, Lulu Mall Walkway, Unnichira, Koonamthai, Edappally, Kochi, Kerala 682024', 0, 'med', 'med', '10.027264', '76.306989', 15),
(23, 'Museum Of Kerala History', 'Salem - Kochi Hwy, Near Hotel Seagate, Koonamthai, Edappally, Ernakulam, Kerala 682024', 2147483647, 'med', 'med', '10.0265211', '76.3022392', 8);

-- --------------------------------------------------------

--
-- Table structure for table `college`
--

CREATE TABLE IF NOT EXISTS `college` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `lattitude` varchar(200) NOT NULL,
  `longitude` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `college`
--

INSERT INTO `college` (`id`, `name`, `lattitude`, `longitude`) VALUES
(1, 'mes college ,aluva', '9.9199936', '76.2561122'),
(2, 'UC College,Aluva', '10.1260401', '76.3337953'),
(3, 'KMM College of Arts & Science', '9.9957925', '76.2755907'),
(4, 'School of Technology and Applied Sciences (STAS)', '9.9957925', '76.2755907');

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE IF NOT EXISTS `details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `number` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`id`, `name`, `address`, `number`) VALUES
(1, 'AL- Taza', 'Ground floor, Radhani Developers, service road, Pulinchodu Junction, Aluva, Kerala 683101', '2147483647'),
(2, 'Ifthar Restaurant', 'Bank Junction, Karshakashree, Aluva, Kochi, Kerala 683101', '2147483647'),
(3, 'AL ARABIA Arabic Food Court', 'Bank Junction, Karshakashree, Aluva, Kochi, Kerala 683101', '2147483647'),
(4, 'Metro Fashion Mall', 'Catholic centre complex, Railway Station Rd, Aluva, Kerala 683101', '2147483647'),
(5, 'LuLu International Shopping Malls Private Limited ', '34/1000, Old NH 47, Edappally Junction, Nethaji Nagar, Edappally, Kochi, Kerala 682024', '2147483647'),
(6, 'Oberon Mall', 'Oberon Mall', '0'),
(7, 'Royal Stay - Gents Hostel in Edappally', '32/429,EGRA - 3A Edappally - Pukkaattupady Road, Near, Lulu Mall Walkway, Unnichira, Koonamthai, Edappally, Kochi, Kerala 682024', '0'),
(8, 'Museum Of Kerala History', 'Salem - Kochi Hwy, Near Hotel Seagate, Koonamthai, Edappally, Ernakulam, Kerala 682024', '2147483647');

-- --------------------------------------------------------

--
-- Table structure for table `preference`
--

CREATE TABLE IF NOT EXISTS `preference` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `college` varchar(100) NOT NULL,
  `food` varchar(100) NOT NULL,
  `shop` varchar(100) NOT NULL,
  `gym` varchar(100) NOT NULL,
  `hospital` varchar(100) NOT NULL,
  `hostels` varchar(100) NOT NULL,
  `theatre` varchar(100) NOT NULL,
  `parks` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=70 ;

--
-- Dumping data for table `preference`
--

INSERT INTO `preference` (`id`, `user_id`, `college`, `food`, `shop`, `gym`, `hospital`, `hostels`, `theatre`, `parks`) VALUES
(5, 1, '--select--', '--select--', '--select--', '--select--', '', '', '', ''),
(6, 1, 'UC College,Aluva', 'Yes', '2', '--select--', 'Yes', 'No', 'Yes', 'No'),
(7, 1, 'UC College,Aluva', 'Yes', '4', '2', 'Yes', 'No', 'Yes', 'No'),
(8, 1, 'UC College,Aluva', '1', '4', '3', 'No', 'No', 'Yes', 'Yes'),
(9, 1, '--select--', 'No', '--select--', '--select--', '', '', '', ''),
(10, 1, 'mes college ,aluva', 'No', '5', '2', 'No', 'Yes', 'No', 'Yes'),
(11, 1, 'UC College,Aluva', '1', '5', '5', 'Yes', 'No', 'Yes', 'Yes'),
(12, 1, 'UC College,Aluva', '1', '5', '5', 'Yes', 'No', 'Yes', 'Yes'),
(13, 1, 'UC College,Aluva', '', '4', '5', 'Yes', 'No', 'Yes', 'Yes'),
(14, 1, 'mes college ,aluva', '1', '4', '2', 'Yes', 'Yes', 'Yes', 'Yes'),
(15, 1, 'mes college ,aluva', '1', '4', '2', 'Yes', 'Yes', 'Yes', 'Yes'),
(16, 1, 'mes college ,aluva', '4', '2', '1', 'Yes', 'Yes', 'Yes', 'Yes'),
(17, 1, 'UC College,Aluva', '5', '5', 'Yes', '13', '15', '11', '8'),
(18, 1, '--select--', '4', '--select--', 'Yes', '13', '15', '11', '8'),
(19, 1, '--select--', '4', '--select--', 'Yes', '13', '15', '11', '8'),
(20, 1, 'mes college ,aluva', '5', '5', '1', '13', '15', 'No', '8'),
(21, 1, 'mes college ,aluva', '2', '2', 'No', '13', '15', '11', '8'),
(22, 1, 'mes college ,aluva', '2', '2', 'No', '13', '15', '11', '8'),
(23, 1, '1', '12', '4', '1', '13', '15', '11', '8'),
(24, 1, '1', '3', '10', '1', '13', '15', 'No', '8'),
(25, 1, '4', '3', '9', '1', '13', '15', '11', '8'),
(26, 1, '--select--', '--select--', '--select--', '--select--', '', '', '', ''),
(27, 8, '1', '2', '9', '1', 'No', '15', '11', 'No'),
(28, 8, '1', '4', '9', '1', '13', '15', 'No', 'No'),
(29, 8, '1', '4', '9', '1', 'No', '15', 'No', '8'),
(30, 8, '1', '2', '9', 'No', '13', '15', '11', 'No'),
(31, 8, '1', '4', '9', 'No', 'No', '15', 'No', '8'),
(32, 8, '1', '4', '9', 'No', 'No', '15', 'No', '8'),
(33, 8, '1', '4', '9', 'No', 'No', '15', 'No', '8'),
(34, 8, '1', '4', '9', 'No', 'No', '15', 'No', '8'),
(35, 8, '1', '4', '9', 'No', 'No', '15', 'No', '8'),
(36, 8, '1', '4', '9', 'No', 'No', '15', 'No', '8'),
(37, 8, '1', '2', '9', 'No', 'No', '15', '11', '8'),
(38, 8, '1', '2', '9', 'No', 'No', '15', '11', '8'),
(39, 8, '1', '2', '9', 'No', 'No', '15', '11', '8'),
(40, 8, '1', '2', '9', 'No', 'No', '15', '11', '8'),
(41, 8, '1', '2', '9', 'No', 'No', '15', '11', '8'),
(42, 8, '1', '2', '9', 'No', 'No', '15', '11', '8'),
(43, 1, '2', '2', '9', '1', 'No', '15', '11', '8'),
(44, 1, '1', '4', '9', 'No', '13', 'No', '11', '8'),
(45, 1, '1', '4', '9', 'No', '13', 'No', '11', '8'),
(46, 1, '1', '4', '9', 'No', '13', 'No', '11', '8'),
(47, 1, '2', '5', '10', '1', '13', '', '11', '8'),
(48, 1, '2', '5', '10', '1', '13', '', '11', '8'),
(49, 1, '4', '3', '10', '1', '13', '15', '11', '8'),
(50, 1, '3', '--select--', '10', '1', '13', '15', '11', '8'),
(51, 1, '2', '5', '9', '1', 'No', '15', '11', '8'),
(52, 1, '1', '4', '10', '1', '13', '15', '11', '8'),
(53, 1, '1', '2', '9', '1', 'No', '15', 'No', '8'),
(54, 1, '1', '4', '9', '1', 'No', '15', '11', '8'),
(55, 1, '1', '4', '9', '1', 'No', '15', '11', '8'),
(56, 1, '1', '4', '9', '1', 'No', '15', '11', '8'),
(57, 1, '1', '5', '9', 'No', 'No', '15', '11', '8'),
(58, 1, '1', '2', '9', 'No', 'No', '15', '11', '8'),
(59, 1, '1', '2', '9', 'No', 'No', '15', '11', '8'),
(60, 1, '1', '2', '9', 'No', 'No', '15', '11', '8'),
(61, 1, '1', '2', '9', 'No', 'No', '15', '11', '8'),
(62, 1, '1', '2', '9', '1', 'No', '15', '11', '8'),
(63, 1, '1', '2', '9', '1', 'No', '15', '11', '8'),
(64, 1, '3', '5', '10', 'No', '13', 'No', 'No', 'No'),
(65, 1, '3', '5', '10', 'No', '13', 'No', 'No', 'No'),
(66, 1, '1', '2', '9', '1', '13', '15', '11', '8'),
(67, 1, '1', '2', '9', '1', '13', '15', '11', '8'),
(68, 1, '2', '2', '9', '1', '13', 'No', 'No', 'No'),
(69, 1, '2', '5', '10', 'No', '13', '15', '11', 'No');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE IF NOT EXISTS `review` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `review` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`id`, `user_id`, `review`) VALUES
(1, 1, 'good');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE IF NOT EXISTS `signup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  `age` int(11) DEFAULT NULL,
  `phno` bigint(11) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `mail` varchar(25) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` bigint(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`,`password`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `name`, `age`, `phno`, `gender`, `mail`, `username`, `password`) VALUES
(1, 'Jins', 32, 9526627792, 'male', 'nazarudheen18@gmail.com', 'jins', 1234),
(2, 'yedhu', 22, 574646467, 'male', 'ggfghj', 'lucifer', 0),
(3, 'ansar', 22, 9745585867, 'male', 'aanzz201@gmail.com', 'anzz', 0),
(4, 'Ajmal', 21, 23456, 'male', 'rttooim', 'ajmal', 23456),
(5, '', 0, 0, 'Gender', '', '', 0),
(8, 'John', 12, 123456789, 'male', 'john@gmail.com', 'john', 123),
(14, 'KFC', 12, 8042754444, 'male', 'kfc@gmail.com', 'kfc', 123),
(15, 'fghfg', 0, 0, 'Gender', 'jhghjghjgj', '', 5555),
(20, 'hii', 23, 1111, 'male', 'ssedrd', 'yui', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
