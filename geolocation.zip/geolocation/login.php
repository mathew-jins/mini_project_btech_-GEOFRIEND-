<?php
include("header.php");
?>


<section class="page-title bg-1">
  <div class="overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="block text-center">
          <h1 class="text-capitalize mb-5 text-lg">WELCOME BACK</h1>

          <!-- <ul class="list-inline breadcumb-nav">
            <li class="list-inline-item"><a href="index.html" class="text-white">Home</a></li>
            <li class="list-inline-item"><span class="text-white">/</span></li>
            <li class="list-inline-item"><a href="#" class="text-white-50">Contact Us</a></li>
          </ul> -->
        </div>
      </div>
    </div>
  </div>
</section>
<!-- contact form start -->



<section class="contact-form-wrap section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="section-title text-center">
                    <h2 class="text-md mb-2">Log In</h2>
                    
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <form  class=" "  action="check.php" method="post">
                 <!-- form message -->
                 

                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <input name="username" id="name" type="text" class="form-control" placeholder=" Username" >
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="form-group">
                                <input name="password" id="email" type="password" class="form-control" placeholder=" Password">
                            </div>
                        </div>
                         

                    <div class="text-center">
                        <input class="btn btn-main btn-round-full" name="submit" type="submit" value="Login"></input>
                    </div>
                </form>
				
			
				
            </div>
        </div>
    </div>
</section>


 <div class="google-map ">
    <div id="map"></div>
</div>
<?php
include("footer.php");
?>