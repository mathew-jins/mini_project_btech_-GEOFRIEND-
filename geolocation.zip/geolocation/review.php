<?php
	include("header.php");
?>
<section class="section appoinment">
	<div class="container">
		<div class="row align-items-center">
			
			<div class="col-lg-12 col-md-10 ">
				<div class="appoinment-wrap mt-5 mt-lg-0">
					<h2 class="mb-2 title-color">Feedback</h2>
					     <form id="#" method="post">

                    <div class="row">
                         <div class="col-lg-6">
                            <div class="form-group">
								<label>Review</label>
								<input type= 'text' name="review" class= "form-control">
								
						 
                            </div>
                        </div>
						
                      
                    </div>
					</div>
                    <input type="submit" class="btn btn-main btn-round-full" name="submit" value="Send" >
                </form>
				
				
				<?php
						$con=mysqli_connect("localhost","root","","learn");
						error_reporting(0);
						if(isset($_POST['submit']))
 
						{

							$a=$_POST['review'];
 
							$ins="INSERT INTO `review`(`user_id`, `review`)
							VALUES('$_SESSION[id]','$a')";
							//echo $ins;
							$res= mysqli_query($con,$ins);
							if($res)
							{
								echo "<script>
								alert('insert successfully');
	   
		
							</script>";
							
						}	


						}
			?>
            </div>
			</div>
		</div>
	</div>
</section>
<?php
	include("footer.php");
?>