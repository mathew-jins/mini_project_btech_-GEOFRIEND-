<?php
	include("header.php");
?>
<section class="section appoinment">
	<div class="container">
		<div class="row align-items-center">
			
			<div class="col-lg-12 col-md-10 ">
				<div class="appoinment-wrap mt-5 mt-lg-0">
					<h2 class="mb-2 title-color">Preference</h2>
					     <form id="#" method="post">

                    <div class="row">
                         <div class="col-lg-6">
                            <div class="form-group">
College Name
<select name="college_name" class="form-control">
<option>--select--</option>
							 <?php
						$con=mysqli_connect("localhost","root","","learn");
						
						 $sel="select * from college";
						 $result=mysqli_query($con,$sel);
						 
						 
						 while($row=mysqli_fetch_array($result))
						 {
						 
						 ?>
<option value="<?php echo $row['id'] ?>"><?php echo $row['name'] ?></option>
						 <?php
						 
						 }
						 ?>
</select>
						 
                            </div>
                        </div>
						<div class="col-lg-6">
                            <div class="form-group">
								Gym Type			
								<select name="gym_type" class="form-control">
								<option>--select--</option>
								<option value="1">Yes</option>
								<option value="No">No</option>
								</select>
					        </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
							Food Type
								<select name="food_type" class="form-control">
									<option>--select--</option>
										<?php
											include("connection.php");
											$sel1="SELECT DISTINCT cat.id, cat.cat_name,cat.type FROM cat_info INNER JOIN cat ON cat_info.cid=cat.id where type='food'";
											$result1=mysqli_query($con,$sel1);
											while($row1=mysqli_fetch_array($result1))
											{
												
											 
										 ?>
								<option value="<?php echo $row1['id'] ?>"><?php echo $row1['cat_name'] ?></option>
										 <?php
										 
										 }
										 ?>
								</select>
			                </div>
                        </div>
						
                        <div class="col-lg-6">
                            <div class="form-group">
							Shop Type
							<select name="shop_type" class="form-control">
								<option>--select--</option>
									
								<?php
											include("connection.php");
											$sel1="SELECT DISTINCT cat.id, cat.cat_name,cat.type FROM cat_info INNER JOIN cat ON cat_info.cid=cat.id where type='shop'";
											$result1=mysqli_query($con,$sel1);
											while($row1=mysqli_fetch_array($result1))
											{
												
											 
										 ?>
								<option value="<?php echo $row1['id'] ?>"><?php echo $row1['cat_name'] ?></option>
										 <?php
										 
										 }
										
													 ?>
								</select>                            
							</div>
                        </div>
						
						<div class="col-lg-6">
                            <div class="form-group">
							Hostels
								<select name="hostel" class="form-control">
									<option value="">--select--</option>
									<option value="15">Yes</option>
									<option value="No">No</option>
								</select>                            
							</div>
                        </div>
						
						<div class="col-lg-6">
                            <div class="form-group">
							Hospitals
								<select name="hospital" class="form-control">
									<option value="">--select--</option>
									<option value="13">Yes</option>
									<option value="No">No</option>
								</select>                            
							</div>
                        </div>

						<div class="col-lg-6">
                            <div class="form-group">
							Theatres
								<select name="theatre" class="form-control">
									<option value="">--select--</option>
									<option value="11">Yes</option>
									<option value="No">No</option>
								</select>                            
							</div>
                        </div>
						
						<div class="col-lg-6">
                            <div class="form-group">
							Parks
								<select name="park" class="form-control">
									<option value="">--select--</option>
									<option value="8">Yes</option>
									<option value="No">No</option>
								</select>                            
							</div>
                        </div>
						

                    </div>
					</div>
                    <input type="submit" class="btn btn-main btn-round-full" name="submit" value="Show" >
                </form>
				
				
				<?php
						$con=mysqli_connect("localhost","root","","learn");
						error_reporting(0);
						if(isset($_POST['submit']))
 
						{

							$a=$_POST['college_name'];
							$b=$_POST['gym_type'];
							$c=$_POST['food_type'];
							$d=$_POST['shop_type'];
							$e=$_POST['hostel'];
							$f=$_POST['hospital'];
							$g=$_POST['theatre'];
							$h=$_POST['park'];
 
							$ins="INSERT INTO `preference`(`user_id`, `college`, `food`, `shop`, `gym`, `hospital`, `hostels`, `theatre`, `parks`)
							VALUES('$_SESSION[id]','$a','$c','$d','$b','$f','$e','$g','$h')";
							//echo $ins;
					
							$cat_list="$a,$b,$c,$d,$e,$f,$g,$h";
							//echo $cat_list;
							$myfile = fopen("cat_list.txt", "w") or die("Unable to open file!");
							fwrite($myfile, $cat_list);
							fclose();
							
							$python = `python map_cat.py`;
							$python = `python map_cat_pred.py`;
							//echo $python;
							
							$res= mysqli_query($con,$ins);
							
								echo "<script>
								
								alert('insert successfully');
								window.location='result_map.php';
	   
		
							</script>";
							


						}
						
			?>
			<!--<iframe src="cat_map.html" title="category map"></iframe>
			<iframe src="cat_map_pred.html" title="category map"></iframe>-->
			
            </div>
			</div>
		</div>
	</div>
</section>
<?php
	include("footer.php");
?>