import mysql.connector
def fun(status,id):
	mydb = mysql.connector.connect(
	  host="localhost",
	  user="root",
	  password="",
	  database="geolocation"
	)

	mycursor = mydb.cursor()

	sql = "UPDATE status SET status = %s WHERE id = %s"
	#val = ("0", "1")
	val = (status, id)

	mycursor.execute(sql, val)

	mydb.commit()

#status="0"
#id="1"	
#fun(status,id)